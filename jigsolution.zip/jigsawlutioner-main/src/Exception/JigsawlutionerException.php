<?php

declare(strict_types=1);

namespace Bywulf\Jigsawlutioner\Exception;

use Exception;

class JigsawlutionerException extends Exception
{
}
