<?php

declare(strict_types=1);

namespace Bywulf\Jigsawlutioner\Exception;

class PieceAnalyzerException extends JigsawlutionerException
{
}
