<?php

declare(strict_types=1);

namespace Bywulf\Jigsawlutioner\Exception;

class PuzzleSolverException extends JigsawlutionerException
{
}
