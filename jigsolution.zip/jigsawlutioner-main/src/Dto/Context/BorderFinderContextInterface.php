<?php

declare(strict_types=1);

namespace Bywulf\Jigsawlutioner\Dto\Context;

interface BorderFinderContextInterface
{
}
