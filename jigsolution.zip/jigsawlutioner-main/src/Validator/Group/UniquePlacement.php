<?php

declare(strict_types=1);

namespace Bywulf\Jigsawlutioner\Validator\Group;

use Symfony\Component\Validator\Constraint;

class UniquePlacement extends Constraint
{
    public int $maxAllowedDoubles = 0;
}
