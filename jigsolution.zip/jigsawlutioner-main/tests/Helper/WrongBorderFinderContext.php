<?php

declare(strict_types=1);

namespace Bywulf\Jigsawlutioner\Tests\Helper;

use Bywulf\Jigsawlutioner\Dto\Context\BorderFinderContextInterface;

class WrongBorderFinderContext implements BorderFinderContextInterface
{
}
